package com.example.myapplicationmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    private TextView userid;
    private EditText edtNumber;
    private Button btn_enter, btn_reset;
    private int id;
    private String ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        userid = findViewById(R.id.textView7);
        edtNumber = findViewById(R.id.editTextTextPassword5);
        btn_enter = findViewById(R.id.button5);
        btn_reset = findViewById(R.id.button6);

        Intent intent = this.getIntent();
        id = intent.getIntExtra("id",100);
        ID = Integer.toString(id);
        userid.setText("你的ID為:"+ID);
    }
}