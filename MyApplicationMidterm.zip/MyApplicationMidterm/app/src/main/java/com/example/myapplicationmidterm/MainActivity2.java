package com.example.myapplicationmidterm;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    private EditText edtName, edtPassWord;
    private Button btn_enter, btn_register;
    private String sname, spassword, snumber;

    private SharedPreferences preference;
    int int_snumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // 取得介面元件
        edtName = (EditText)findViewById(R.id.editTextTextPersonName);
        edtPassWord = (EditText)findViewById(R.id.editTextTextPassword2);
        btn_enter = (Button)findViewById(R.id.button3);
        btn_register = (Button)findViewById(R.id.button4);

        // 設定 button 的 Listener
        btn_enter.setOnClickListener(btnHomeListener);
        btn_register.setOnClickListener(btnHomeListener);

    }

    private Button.OnClickListener btnHomeListener = new Button.OnClickListener() {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button3: {//確認註冊
                    snumber = getSharedPreferences("test", MODE_PRIVATE)
                            .getString("number", "");

                    if(snumber.equals(""))
                    {
                        sname = edtName.getText().toString();
                        spassword = edtPassWord.getText().toString();

                        preference = getSharedPreferences("test", 0);
                        preference.edit()
                                .putString("number", Integer.toString(1))
                                .putString("USER"+1, sname)
                                .putString("password"+1, spassword)
                                .commit();

                        new AlertDialog.Builder(MainActivity2.this)
                                .setTitle("註冊成功！")
                                .setMessage("編號為:"+1)
                                .setPositiveButton("確定", new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialoginterface, int i)
                                    {
                                        finish();
                                    }
                                })
                                .show();
                        break;
                    }
                    else
                    {
                        sname = edtName.getText().toString();
                        spassword = edtPassWord.getText().toString();

                        int_snumber = Integer.parseInt(snumber)+1;

                        preference = getSharedPreferences("test", 0);
                        preference.edit()
                                .putString("number", Integer.toString(int_snumber))
                                .putString("USER"+int_snumber, sname)
                                .putString("password"+int_snumber, spassword)
                                .commit();

                        new AlertDialog.Builder(MainActivity2.this)
                                .setTitle("註冊成功！")
                                .setMessage("編號為:"+int_snumber)
                                .setPositiveButton("確定", new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialoginterface, int i)
                                    {
                                        finish();
                                    }
                                })
                                .show();
                        break;
                    }
                }
                case R.id.button4: {//取消註冊
                    finish();
                    break;
                }

            }
        }
    };
}