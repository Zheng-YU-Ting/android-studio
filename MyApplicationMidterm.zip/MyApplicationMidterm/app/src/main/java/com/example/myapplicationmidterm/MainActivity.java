package com.example.myapplicationmidterm;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText name, password;
    private Button btn_enter, btn_register;
    private String sname, spassword, snumber;
    private SharedPreferences preference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 取得介面元件
        name = findViewById(R.id.editTextTextPersonName2);
        password = findViewById(R.id.editTextTextPassword);
        btn_enter = findViewById(R.id.button);
        btn_register = findViewById(R.id.button2);

        // 設定 button 的 Listener
        btn_enter.setOnClickListener(btnHomeListener);
        btn_register.setOnClickListener(btnHomeListener);

    }

    private Button.OnClickListener btnHomeListener = new Button.OnClickListener() {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button: {//註冊
                    Intent intent=new Intent();
                    intent.setClass(MainActivity.this, MainActivity2.class);

                    startActivity(intent);
                    break;
                }
                case R.id.button2: {//登入

                    snumber = getSharedPreferences("test", MODE_PRIVATE)
                            .getString("number", "1");

                    for(int id=1; id<=Integer.parseInt(snumber); id++)
                    {
                        sname = getSharedPreferences("test", MODE_PRIVATE)
                                .getString("USER"+id, "error");
                        spassword = getSharedPreferences("test", MODE_PRIVATE)
                                .getString("password"+id, "error");

                        if(name.getText().toString().equals(sname) && password.getText().toString().equals(spassword))
                        {
                            int finalId = id;
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("登入成功！")
                                    .setMessage("歡迎使用本軟體")
                                    .setPositiveButton("確定", new DialogInterface.OnClickListener()
                                    {
                                        public void onClick(DialogInterface dialoginterface, int i)
                                        {
                                            Intent intent=new Intent();
                                            intent.setClass(MainActivity.this, MainActivity3.class);

                                            int ID = finalId;
                                            intent.putExtra("id", ID);

                                            startActivity(intent);
                                        }
                                    })
                                    .show();
                            break;
                        }
                        else
                        {
                            if(id == Integer.parseInt(snumber))
                            {
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("登入錯誤")
                                        .setMessage("帳號密碼輸入錯誤")
                                        .setPositiveButton("確認", new DialogInterface.OnClickListener()
                                        {
                                            public void onClick(DialogInterface dialoginterface, int i)
                                            {

                                            }
                                        })
                                        .show();
                            }
                        }
                    }
                    break;
                }

            }
        }
    };
}